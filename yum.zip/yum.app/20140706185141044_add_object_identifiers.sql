ALTER TABLE conversations ADD COLUMN object_identifier TEXT;

ALTER TABLE messages ADD COLUMN object_identifier TEXT;
